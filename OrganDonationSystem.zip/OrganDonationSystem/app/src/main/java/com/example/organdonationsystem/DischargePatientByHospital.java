package com.example.organdonationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DischargePatientByHospital extends AppCompatActivity {
    EditText regno,pname,contactno,Emailid,admitted,date1,registrationno;
    Button Editbtn,Check;
    AddPateintClass f;
    String regno1,pname1,contactno1,Emailid1,admitted1,regno2,date12;
    FirebaseAuth mAuth;
    DatabaseReference clinicdb;
    DatabaseReference ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discharge_patient_by_hospital);
        regno=(EditText) findViewById(R.id.regno);
        registrationno=(EditText)findViewById(R.id.registrationno);
        pname=(EditText) findViewById(R.id.pname);
        contactno=(EditText) findViewById(R.id.contactno);
        Emailid=(EditText) findViewById(R.id.Emailid);
        admitted=(EditText) findViewById(R.id.admitted);
        Editbtn=(Button) findViewById(R.id.Editbtn);
        mAuth= FirebaseAuth.getInstance();
        Check = (Button) findViewById(R.id.Check);
        date1=(EditText)findViewById(R.id.date1);
        clinicdb = FirebaseDatabase.getInstance().getReference().child("AdmitPatientInfo");
        Check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                regno2 = registrationno.getText().toString();
                System.out.println("user given reg no"+regno2);
                ref = FirebaseDatabase.getInstance().getReference().child("AdmitPatientInfo");
                ref.orderByChild("registrationNo1").equalTo(regno2)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()) {
                                    System.out.println("Data present");
                                    int i = 1;
                                    System.out.println("Hi2");
                                    for (DataSnapshot ds : snapshot.getChildren()) {
                                        System.out.println("Hi3");
                                        f = ds.getValue(AddPateintClass.class);
                                        regno.setText(f.getRegistrationNo1());
                                        pname.setText(f.getPatientName1());
                                        contactno.setText(f.getPateintContactNo1());
                                        Emailid.setText(f.getEmailid1());
                                        date1.setText(f.getDateInfo());
                                        admitted.setText(f.getAdmitstatus());
                                    }

                                    i++;
                                }


                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }


                        });
            }
        });
        Editbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               pname1=pname.getText().toString();
                contactno1=contactno.getText().toString();
                Emailid1=Emailid.getText().toString();
                admitted1=admitted.getText().toString();
                date12=date1.getText().toString();
                AddPateintClass f=new AddPateintClass(regno2,pname1,contactno1,Emailid1,date12,admitted1);
                clinicdb.child(regno2).setValue(f);
                Toast.makeText(DischargePatientByHospital.this,"store information sucessfully",Toast.LENGTH_SHORT).show();

            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater m=getMenuInflater();
        m.inflate(R.menu.hospitalsidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
                Intent intent = new Intent(getApplicationContext(), HospitalHomePage.class);
                startActivity(intent);
                break;
            case R.id.FillOrganInformation:
                Intent intent2 = new Intent(getApplicationContext(), DonateOrgan.class);
                startActivity(intent2);
                break;
            case R.id.CheckOrganDonationInformation:
                Intent intent3 = new Intent(getApplicationContext(),CheckOrganDonationInformationToDonar.class);
                startActivity(intent3);
                break;
            case R.id.CheckFeedback:
                Intent intent31 = new Intent(getApplicationContext(),CheckFeedback.class);
                startActivity(intent31);
                break;
            case R.id.changepass:
                Intent intent311= new Intent(getApplicationContext(),ChangePasswordForHospital.class);
                startActivity(intent311);
                break;
            case R.id.Feedback:
                Intent intent199 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent199);
                break;
            case R.id.SignOut:
                Intent intent4 = new Intent(getApplicationContext(),IndexPage.class);
                startActivity(intent4);
                break;
            case R.id.AdmitPatient:
                Intent intent41 = new Intent(getApplicationContext(),AddPatient.class);
                startActivity(intent41);
                break;
            case R.id.CheckAdmitPatient:
                Intent intent421 = new Intent(getApplicationContext(),CheckAdmitPatient.class);
                startActivity(intent421);
                break;
            case R.id.ReleasePatient:
                Intent intent4211 = new Intent(getApplicationContext(),DischargePatientByHospital.class);
                startActivity(intent4211);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}