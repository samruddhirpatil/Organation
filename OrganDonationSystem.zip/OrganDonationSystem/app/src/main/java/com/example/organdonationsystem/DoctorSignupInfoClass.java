package com.example.organdonationsystem;

public class DoctorSignupInfoClass {
    String RegistrationNo,DoctName,Doctaddress,DoctContactNo,DoctEmailid,DoctUsername,DoctPass;

    public DoctorSignupInfoClass(){}
    public DoctorSignupInfoClass(String doctUsername,String doctPass){
        DoctUsername = doctUsername;
        DoctPass = doctPass;
    }
    public DoctorSignupInfoClass(String registrationNo, String doctName, String doctaddress, String doctContactNo, String doctEmailid, String doctUsername, String doctPass) {
        RegistrationNo = registrationNo;
        DoctName = doctName;
        Doctaddress = doctaddress;
        DoctContactNo = doctContactNo;
        DoctEmailid = doctEmailid;
        DoctUsername = doctUsername;
        DoctPass = doctPass;
    }

    public String getRegistrationNo() {
        return RegistrationNo;
    }

    public void setRegistrationNo(String registrationNo) {
        RegistrationNo = registrationNo;
    }

    public String getDoctName() {
        return DoctName;
    }

    public void setDoctName(String doctName) {
        DoctName = doctName;
    }

    public String getDoctaddress() {
        return Doctaddress;
    }

    public void setDoctaddress(String doctaddress) {
        Doctaddress = doctaddress;
    }

    public String getDoctContactNo() {
        return DoctContactNo;
    }

    public void setDoctContactNo(String doctContactNo) {
        DoctContactNo = doctContactNo;
    }

    public String getDoctEmailid() {
        return DoctEmailid;
    }

    public void setDoctEmailid(String doctEmailid) {
        DoctEmailid = doctEmailid;
    }

    public String getDoctUsername() {
        return DoctUsername;
    }

    public void setDoctUsername(String doctUsername) {
        DoctUsername = doctUsername;
    }

    public String getDoctPass() {
        return DoctPass;
    }

    public void setDoctPass(String doctPass) {
        DoctPass = doctPass;
    }
}
