package com.example.organdonationsystem;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.se.omapi.Session;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class ForgetPasswordForDonor extends AppCompatActivity {
    String[] courses = {"Hospital", "Donor", "Doctor", "Organ Receiver"};
    String emailid="odonation2023";
    //String passwordEmail="Odonation@2023";
    String passwordEmail="alrfznfnkiajzymr",M;
    EditText username, email;
    DatabaseReference organdb,organdb1,organdb2,organdb3;
    Button send;
    EditText mobile;
    String authpass;
    String u, e;
    private String mailhost = "smtp.gmail.com";
    private Session session;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password_for_donor);
        username = (EditText) findViewById(R.id.username);
        email = (EditText) findViewById(R.id.email);
        send = (Button) findViewById(R.id.send);
        mobile=(EditText)findViewById(R.id.mobile);
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                u = username.getText().toString();
                e = email.getText().toString();
                System.out.println("email=" + e);
                String stringHost = "smtp.gmail.com";

                Properties properties = System.getProperties();

                properties.put("mail.smtp.host", stringHost);
                properties.put("mail.smtp.port", "465");
                properties.put("mail.smtp.ssl.enable", "true");
                properties.put("mail.smtp.auth", "true");
                organdb = FirebaseDatabase.getInstance().getReference().child("DonorSignupInfo");
                organdb.child(u).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                    @SuppressLint("LongLogTag")
                    @Override
                    public void onComplete(@NonNull Task<DataSnapshot> task) {

                        if (!task.isSuccessful()) {
                            Log.e("firebase", "Error getting data", task.getException());
                        } else {
                            authpass = task.getResult().child("donorPass1").getValue().toString();
                            System.out.println("Authpass="+authpass);
                            System.out.println("Username="+u);
                            System.out.println("em="+e);
                            javax.mail.Session session = javax.mail.Session.getInstance(properties, new Authenticator() {
                                @Override
                                protected PasswordAuthentication getPasswordAuthentication() {
                                    return new PasswordAuthentication(emailid, passwordEmail);
                                }
                            });

                            MimeMessage mimeMessage = new MimeMessage(session);
                            try {
                                mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(e));
                                mimeMessage.setSubject("Subject: Your password");
                                mimeMessage.setText("Your password is=" + authpass);
                                Intent intent4 = new Intent(getApplicationContext(), DonarLogin.class);
                                startActivity(intent4);
                            } catch (MessagingException ex) {
                                throw new RuntimeException(ex);
                            }

                            Thread thread = new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        Transport.send(mimeMessage);
                                    } catch (MessagingException e) {
                                        e.printStackTrace();
                                    }
                                }
                            });
                            thread.start();
                        }

                        M=mobile.getText().toString();
                        if(checkPermssion(android.Manifest.permission.SEND_SMS))
                        {
                            //  withdrawbtn.setEnabled(true);
                        }
                        else
                        {
                            ActivityCompat.requestPermissions(ForgetPasswordForDonor.this, new String[]{android.Manifest.permission.SEND_SMS},1);

                        }
                        if(checkPermssion(Manifest.permission.SEND_SMS))
                        {
                            String sms1="Your password="+authpass;
                            SmsManager smsManager=SmsManager.getDefault();
                            smsManager.sendTextMessage(M,null,sms1,null,null);
                            Toast.makeText(getApplicationContext(),"Message Sent",Toast.LENGTH_LONG).show();

                        }

                        else
                        {
                            Toast.makeText(getApplicationContext(),"Some fields is Empty",Toast.LENGTH_LONG).show();
                        }

                    }


                });
            }
        });
    }
    public  boolean checkPermssion(String permission)
    {
        int check= ContextCompat.checkSelfPermission(this,permission);
        return (check== PackageManager.PERMISSION_GRANTED);
    }

}

