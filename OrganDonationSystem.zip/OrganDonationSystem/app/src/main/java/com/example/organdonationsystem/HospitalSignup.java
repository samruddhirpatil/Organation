package com.example.organdonationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HospitalSignup extends AppCompatActivity {
    EditText RegistrationNo,HospName,Hospaddress,HospContactNo,HospEmailid,HospUsername,HospPass,HospCPass;
    Button signupbtn;
    String RegistrationNo1,HospName1,Hospaddress1,HospContactNo1,HospEmailid1,HospUsername1,HospPass1,HospCPass1;
    DatabaseReference organDB;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital_signup);
        signupbtn=(Button) findViewById(R.id.signupbtn);
        RegistrationNo=(EditText) findViewById(R.id.RegistrationNo);
        HospName=(EditText) findViewById(R.id.HospName);
        Hospaddress=(EditText) findViewById(R.id.Hospaddress);
        HospContactNo=(EditText) findViewById(R.id.HospContactNo);
        HospEmailid=(EditText) findViewById(R.id.HospEmailid);
        HospUsername=(EditText) findViewById(R.id.HospUsername);
        HospPass=(EditText) findViewById(R.id.HospPass);
        HospCPass=(EditText) findViewById(R.id.HospCPass);
        mAuth=FirebaseAuth.getInstance();
        organDB = FirebaseDatabase.getInstance().getReference().child("HospitalSignupInfo");

        signupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegistrationNo1=RegistrationNo.getText().toString();
                HospName1=HospName.getText().toString();
                Hospaddress1=Hospaddress.getText().toString();
                HospContactNo1=HospContactNo.getText().toString();
                HospEmailid1=HospEmailid.getText().toString().trim();
                HospUsername1=HospUsername.getText().toString();
                HospPass1=HospPass.getText().toString().trim();
                HospCPass1=HospCPass.getText().toString().trim();
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                if (HospEmailid1.matches(emailPattern) && HospEmailid1.length() > 0 && android.util.Patterns.PHONE.matcher(HospContactNo1).matches()&& HospPass1.length()>8 && isValidPassword(HospCPass1))
                {
                    //Toast.makeText(getApplicationContext(),"valid email address",Toast.LENGTH_SHORT).show();


                    if(HospPass1.equals(HospCPass1))
                {
                    HospitalSignupStoreClass f = new HospitalSignupStoreClass(RegistrationNo1,HospName1,Hospaddress1,HospContactNo1,HospEmailid1,HospUsername1,HospPass1,HospCPass1);
                    organDB.child(HospUsername1).setValue(f);
                    Toast.makeText(HospitalSignup.this, "Signup successfully", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(HospitalSignup.this, HospitalLogin.class);
                    startActivity(i);
                }}else {
                    Toast.makeText(getApplicationContext(),"Invalid email address or email or password",Toast.LENGTH_SHORT).show();

                }


            }
        });
    }
 public boolean onCreateOptionsMenu(Menu menu)
{
    MenuInflater m=getMenuInflater();
    m.inflate(R.menu.commonsidemenu, menu);
    return true;
}
@Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:

                Intent intent = new Intent(getApplicationContext(), IndexPage.class);
                startActivity(intent);
                break;
            case R.id.Doctor_Login:

                Intent intent2 = new Intent(getApplicationContext(), DoctorLogin.class);
                startActivity(intent2);
                break;
            case R.id.HospitalLogin:

                Intent intent4 = new Intent(getApplicationContext(),HospitalLogin.class);
                startActivity(intent4);
                break;
            case R.id.Donor:

                Intent intent3 = new Intent(getApplicationContext(),DonarLogin.class);
                startActivity(intent3);
                break;
            case R.id.Feedback:
                Intent intent6 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent6);
            case R.id.ContactUs:

                Intent intent5 = new Intent(getApplicationContext(), ContactUs.class);
                startActivity(intent5);
            case R.id.Receiver:

                Intent intent7 = new Intent(getApplicationContext(), OrganRecieveLogin.class);
                startActivity(intent7);

        }
        return super.onOptionsItemSelected(item);
    }
    public static boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();

    }
}