package com.example.organdonationsystem;

public class DonateOrganDetailsStoreClass {
    String DonarName1,age1,DonarAddress1,DonarContactNo1,DonarEmailid1,Adhar1,OrganName1,WhenDonate1,gender,donatedStatus,alive;
    public DonateOrganDetailsStoreClass(){}

    public DonateOrganDetailsStoreClass(String donarName1, String age1, String donarAddress1, String donarContactNo1, String donarEmailid1, String adhar1, String organName1, String whenDonate1, String gender, String donatedStatus, String alive) {
        DonarName1 = donarName1;
        this.age1 = age1;
        DonarAddress1 = donarAddress1;
        DonarContactNo1 = donarContactNo1;
        DonarEmailid1 = donarEmailid1;
        Adhar1 = adhar1;
        OrganName1 = organName1;
        WhenDonate1 = whenDonate1;
        this.gender = gender;
        this.donatedStatus = donatedStatus;
        this.alive = alive;
    }

    public String getDonatedStatus() {
        return donatedStatus;
    }

    public void setDonatedStatus(String donatedStatus) {
        this.donatedStatus = donatedStatus;
    }

    public String getAlive() {
        return alive;
    }

    public void setAlive(String alive) {
        this.alive = alive;
    }

    public String getDonarName1() {
        return DonarName1;
    }

    public void setDonarName1(String donarName1) {
        DonarName1 = donarName1;
    }

    public String getAge1() {
        return age1;
    }

    public void setAge1(String age1) {
        this.age1 = age1;
    }

    public String getDonarAddress1() {
        return DonarAddress1;
    }

    public void setDonarAddress1(String donarAddress1) {
        DonarAddress1 = donarAddress1;
    }

    public String getDonarContactNo1() {
        return DonarContactNo1;
    }

    public void setDonarContactNo1(String donarContactNo1) {
        DonarContactNo1 = donarContactNo1;
    }

    public String getDonarEmailid1() {
        return DonarEmailid1;
    }

    public void setDonarEmailid1(String donarEmailid1) {
        DonarEmailid1 = donarEmailid1;
    }

    public String getAdhar1() {
        return Adhar1;
    }

    public void setAdhar1(String adhar1) {
        Adhar1 = adhar1;
    }

    public String getOrganName1() {
        return OrganName1;
    }

    public void setOrganName1(String organName1) {
        OrganName1 = organName1;
    }

    public String getWhenDonate1() {
        return WhenDonate1;
    }

    public void setWhenDonate1(String whenDonate1) {
        WhenDonate1 = whenDonate1;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
