package com.example.organdonationsystem;

public class HospitalSignupStoreClass {
    String RegistrationNo1,HospName1,Hospaddress1,HospContactNo1,HospEmailid1,HospUsername1,HospPass1,HospCPass1;

    public HospitalSignupStoreClass(String registrationNo1, String hospName1, String hospaddress1, String hospContactNo1, String hospEmailid1, String hospUsername1, String hospPass1, String hospCPass1) {
        RegistrationNo1 = registrationNo1;
        HospName1 = hospName1;
        Hospaddress1 = hospaddress1;
        HospContactNo1 = hospContactNo1;
        HospEmailid1 = hospEmailid1;
        HospUsername1 = hospUsername1;
        HospPass1 = hospPass1;
        HospCPass1 = hospCPass1;
    }

    public String getRegistrationNo1() {
        return RegistrationNo1;
    }

    public void setRegistrationNo1(String registrationNo1) {
        RegistrationNo1 = registrationNo1;
    }

    public String getHospName1() {
        return HospName1;
    }

    public void setHospName1(String hospName1) {
        HospName1 = hospName1;
    }

    public String getHospaddress1() {
        return Hospaddress1;
    }

    public void setHospaddress1(String hospaddress1) {
        Hospaddress1 = hospaddress1;
    }

    public String getHospContactNo1() {
        return HospContactNo1;
    }

    public void setHospContactNo1(String hospContactNo1) {
        HospContactNo1 = hospContactNo1;
    }

    public String getHospEmailid1() {
        return HospEmailid1;
    }

    public void setHospEmailid1(String hospEmailid1) {
        HospEmailid1 = hospEmailid1;
    }

    public String getHospUsername1() {
        return HospUsername1;
    }

    public void setHospUsername1(String hospUsername1) {
        HospUsername1 = hospUsername1;
    }

    public String getHospPass1() {
        return HospPass1;
    }

    public void setHospPass1(String hospPass1) {
        HospPass1 = hospPass1;
    }

    public String getHospCPass1() {
        return HospCPass1;
    }

    public void setHospCPass1(String hospCPass1) {
        HospCPass1 = hospCPass1;
    }
}
