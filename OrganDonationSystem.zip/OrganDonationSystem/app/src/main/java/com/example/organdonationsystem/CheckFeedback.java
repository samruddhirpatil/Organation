package com.example.organdonationsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CheckFeedback extends AppCompatActivity {
    private ListView listView;
    FirebaseDatabase database;
    // creating a new array list.
    ArrayList<String> list;
    ArrayAdapter<String> adapter;
    FeedbackFormStore feed;
    // creating a variable for database reference.
    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_feedback);
        feed=new FeedbackFormStore();
        listView = (ListView) findViewById(R.id.listView);
        database=FirebaseDatabase.getInstance();
        list=new ArrayList<>();
        ref = FirebaseDatabase.getInstance().getReference().child("Feedback");
        adapter=new ArrayAdapter<String>(this,R.layout.feedbackinfo,R.id.Feedback_info,list);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int i=1;
                for(DataSnapshot ds:snapshot.getChildren())
                {
                    feed=ds.getValue(FeedbackFormStore.class);
                    list.add("\n"+i+" Mobile no="+feed.getMob().toString()+"\nFeedback= "+feed.getFeedback().toString()+"\n");
                    i++;
                }
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater m=getMenuInflater();
        m.inflate(R.menu.hospitalsidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
                Intent intent = new Intent(getApplicationContext(), DonorHomePage.class);
                startActivity(intent);
                break;
            case R.id.FillOrganInformation:
                Intent intent2 = new Intent(getApplicationContext(), DonateOrgan.class);
                startActivity(intent2);
                break;
            case R.id.CheckOrganDonationInformation:
                Intent intent3 = new Intent(getApplicationContext(),CheckOrganDonationInformationToDonar.class);
                startActivity(intent3);
                break;
            case R.id.CheckFeedback:
                Intent intent31 = new Intent(getApplicationContext(),CheckFeedback.class);
                startActivity(intent31);
                break;
            case R.id.SignOut:
                Intent intent4 = new Intent(getApplicationContext(),IndexPage.class);
                startActivity(intent4);
                break;


        }
        return super.onOptionsItemSelected(item);
    }

}