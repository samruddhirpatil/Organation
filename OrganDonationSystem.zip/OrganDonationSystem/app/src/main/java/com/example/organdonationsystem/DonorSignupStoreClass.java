package com.example.organdonationsystem;

public class DonorSignupStoreClass {
    String DonorName1,DonorAddress1,DonorContactNo1,DonorEmailid1,DonorUsername1,DonorPass1,DonorCPass1;

    public DonorSignupStoreClass(String donorName1, String donorAddress1, String donorContactNo1, String donorEmailid1, String donorUsername1, String donorPass1, String donorCPass1) {
        DonorName1 = donorName1;
        DonorAddress1 = donorAddress1;
        DonorContactNo1 = donorContactNo1;
        DonorEmailid1 = donorEmailid1;
        DonorUsername1 = donorUsername1;
        DonorPass1 = donorPass1;
        DonorCPass1 = donorCPass1;
    }

    public String getDonorName1() {
        return DonorName1;
    }

    public void setDonorName1(String donorName1) {
        DonorName1 = donorName1;
    }

    public String getDonorAddress1() {
        return DonorAddress1;
    }

    public void setDonorAddress1(String donorAddress1) {
        DonorAddress1 = donorAddress1;
    }

    public String getDonorContactNo1() {
        return DonorContactNo1;
    }

    public void setDonorContactNo1(String donorContactNo1) {
        DonorContactNo1 = donorContactNo1;
    }

    public String getDonorEmailid1() {
        return DonorEmailid1;
    }

    public void setDonorEmailid1(String donorEmailid1) {
        DonorEmailid1 = donorEmailid1;
    }

    public String getDonorUsername1() {
        return DonorUsername1;
    }

    public void setDonorUsername1(String donorUsername1) {
        DonorUsername1 = donorUsername1;
    }

    public String getDonorPass1() {
        return DonorPass1;
    }

    public void setDonorPass1(String donorPass1) {
        DonorPass1 = donorPass1;
    }

    public String getDonorCPass1() {
        return DonorCPass1;
    }

    public void setDonorCPass1(String donorCPass1) {
        DonorCPass1 = donorCPass1;
    }
}
