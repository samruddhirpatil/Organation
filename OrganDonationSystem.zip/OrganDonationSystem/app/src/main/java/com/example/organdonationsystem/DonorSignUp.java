package com.example.organdonationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DonorSignUp extends AppCompatActivity {
Button signup;
EditText DonorName,DonorAddress,DonorContactNo,DonorEmailid,DonorUsername,DonorPass,DonorCPass;
String DonorName1,DonorAddress1,DonorContactNo1,DonorEmailid1,DonorUsername1,DonorPass1,DonorCPass1;
    DatabaseReference organDB;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor_sign_up);
        signup = (Button) findViewById(R.id.signupbtn);
        DonorName=(EditText)findViewById(R.id.ReceiverName);
        DonorAddress=(EditText) findViewById(R.id.ReceiverAddress);
        DonorContactNo=(EditText) findViewById(R.id.HospContactNo);
        DonorEmailid=(EditText) findViewById(R.id.HospEmailid);
        DonorUsername=(EditText) findViewById(R.id.HospUsername);
        DonorPass=(EditText) findViewById(R.id.HospPass);
        DonorCPass=(EditText) findViewById(R.id.HospCPass);
        mAuth= FirebaseAuth.getInstance();
        organDB = FirebaseDatabase.getInstance().getReference().child("DonorSignupInfo");
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DonorName1=DonorName.getText().toString();
                DonorAddress1=DonorAddress.getText().toString();
                DonorContactNo1=DonorContactNo.getText().toString();
                DonorEmailid1=DonorEmailid.getText().toString();
                DonorUsername1=DonorUsername.getText().toString();
                DonorPass1=DonorPass.getText().toString();
                DonorCPass1=DonorCPass.getText().toString();
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                if (DonorEmailid1.matches(emailPattern) && DonorEmailid1.length() > 0 && android.util.Patterns.PHONE.matcher(DonorContactNo1).matches()&& DonorPass1.length()>8 && isValidPassword(DonorPass1))
                {
                    //Toast.makeText(getApplicationContext(),"valid email address",Toast.LENGTH_SHORT).show();

                if(DonorCPass1.equals(DonorPass1))
                {
                    DonorSignupStoreClass f = new DonorSignupStoreClass(DonorName1,DonorAddress1,DonorContactNo1,DonorEmailid1,DonorUsername1,DonorPass1,DonorCPass1);
                    // societydb.push().setValue(f);
                    organDB.child(DonorUsername1).setValue(f);
                    Toast.makeText(DonorSignUp.this, "Signup successfully", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(DonorSignUp.this, DonarLogin.class);
                    startActivity(i);
                }}else {
                    Toast.makeText(getApplicationContext(),"Invalid email address or email or password",Toast.LENGTH_SHORT).show();

                }


            }
        });

    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater m=getMenuInflater();
        m.inflate(R.menu.commonsidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
                Intent intent = new Intent(getApplicationContext(), IndexPage.class);
                startActivity(intent);
                break;
            case R.id.Doctor_Login:
                Intent intent2 = new Intent(getApplicationContext(), DoctorLogin.class);
                startActivity(intent2);
                break;
            case R.id.HospitalLogin:
                Intent intent3 = new Intent(getApplicationContext(),HospitalLogin.class);
                startActivity(intent3);
                break;
            case R.id.Donor:
                Intent intent4 = new Intent(getApplicationContext(),DonarLogin.class);
                startActivity(intent4);
                break;
            case R.id.Receiver:
                Intent intent5 = new Intent(getApplicationContext(), OrganRecieveLogin.class);
                startActivity(intent5);
                break;
            case R.id.Feedback:
                Intent intent6 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent6);
                break;
            case R.id.ContactUs:
                Intent intent7 = new Intent(getApplicationContext(), ContactUs.class);
                startActivity(intent7);
                break;

        }
        return super.onOptionsItemSelected(item);
    }
    public static boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();

    }
}