package com.example.organdonationsystem;

public class RecieverSignupDetailsStoreClass {
    String ReceiverName1,ReceiverAddress1,HospContactNo1,HospEmailid1,RecieverUsername1,ReciverPass1,ReciverCPass1;

    public RecieverSignupDetailsStoreClass(String receiverName1, String receiverAddress1, String hospContactNo1, String hospEmailid1, String recieverUsername1, String reciverPass1, String reciverCPass1) {
        ReceiverName1 = receiverName1;
        ReceiverAddress1 = receiverAddress1;
        HospContactNo1 = hospContactNo1;
        HospEmailid1 = hospEmailid1;
        RecieverUsername1 = recieverUsername1;
        ReciverPass1 = reciverPass1;
        ReciverCPass1 = reciverCPass1;
    }

    public String getReceiverName1() {
        return ReceiverName1;
    }

    public void setReceiverName1(String receiverName1) {
        ReceiverName1 = receiverName1;
    }

    public String getReceiverAddress1() {
        return ReceiverAddress1;
    }

    public void setReceiverAddress1(String receiverAddress1) {
        ReceiverAddress1 = receiverAddress1;
    }

    public String getHospContactNo1() {
        return HospContactNo1;
    }

    public void setHospContactNo1(String hospContactNo1) {
        HospContactNo1 = hospContactNo1;
    }

    public String getHospEmailid1() {
        return HospEmailid1;
    }

    public void setHospEmailid1(String hospEmailid1) {
        HospEmailid1 = hospEmailid1;
    }

    public String getRecieverUsername1() {
        return RecieverUsername1;
    }

    public void setRecieverUsername1(String recieverUsername1) {
        RecieverUsername1 = recieverUsername1;
    }

    public String getReciverPass1() {
        return ReciverPass1;
    }

    public void setReciverPass1(String reciverPass1) {
        ReciverPass1 = reciverPass1;
    }

    public String getReciverCPass1() {
        return ReciverCPass1;
    }

    public void setReciverCPass1(String reciverCPass1) {
        ReciverCPass1 = reciverCPass1;
    }
}
