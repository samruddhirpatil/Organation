package com.example.organdonationsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DonateOrganByHospital extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donate_organ_by_hospital);
    }
}