package com.example.organdonationsystem;

public class AddPateintClass {
    String RegistrationNo1,PatientName1,PateintContactNo1,Emailid1,dateInfo,Admitstatus;

    public AddPateintClass(String registrationNo1, String patientName1, String pateintContactNo1, String emailid1, String dateInfo, String admitstatus) {
        RegistrationNo1 = registrationNo1;
        PatientName1 = patientName1;
        PateintContactNo1 = pateintContactNo1;
        Emailid1 = emailid1;
        this.dateInfo = dateInfo;
        Admitstatus = admitstatus;
    }
    public AddPateintClass(){}
    public String getRegistrationNo1() {
        return RegistrationNo1;
    }

    public void setRegistrationNo1(String registrationNo1) {
        RegistrationNo1 = registrationNo1;
    }

    public String getPatientName1() {
        return PatientName1;
    }

    public void setPatientName1(String patientName1) {
        PatientName1 = patientName1;
    }

    public String getPateintContactNo1() {
        return PateintContactNo1;
    }

    public void setPateintContactNo1(String pateintContactNo1) {
        PateintContactNo1 = pateintContactNo1;
    }

    public String getEmailid1() {
        return Emailid1;
    }

    public void setEmailid1(String emailid1) {
        Emailid1 = emailid1;
    }

    public String getDateInfo() {
        return dateInfo;
    }

    public void setDateInfo(String dateInfo) {
        this.dateInfo = dateInfo;
    }

    public String getAdmitstatus() {
        return Admitstatus;
    }

    public void setAdmitstatus(String admitstatus) {
        Admitstatus = admitstatus;
    }
}
