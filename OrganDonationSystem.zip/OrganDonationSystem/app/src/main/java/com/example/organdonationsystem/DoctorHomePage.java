package com.example.organdonationsystem;

import static com.example.organdonationsystem.DoctorLogin.activityname13;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class DoctorHomePage extends AppCompatActivity {
    SharedPreferences sharedpreferences13;
    public static final String SHARED_PREFS13 = "shared_prefs13";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_home_page);
        sharedpreferences13 = getSharedPreferences(SHARED_PREFS13, Context.MODE_PRIVATE);
        String  fn12= sharedpreferences13.getString(activityname13, null);
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater m=getMenuInflater();
        m.inflate(R.menu.doctorsidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
                Intent intent = new Intent(getApplicationContext(), DoctorHomePage.class);
                startActivity(intent);
                break;
            case R.id.FillOrganInformation:
                Intent intent2 = new Intent(getApplicationContext(), DonateOrgan.class);
                startActivity(intent2);
                break;
            case R.id.CheckOrganDonationInformation:
                Intent intent3 = new Intent(getApplicationContext(),CheckOrganDonationInformationToDonar.class);
                startActivity(intent3);
                break;
            case R.id.Feedback:
                Intent intent199 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent199);
                break;
            case R.id.changepass:
                Intent intent99 = new Intent(getApplicationContext(), ChangePassword.class);
                startActivity(intent99);
                break;
            case R.id.SignOut:
                Intent intent4 = new Intent(getApplicationContext(),IndexPage.class);
                startActivity(intent4);
                break;


        }
        return super.onOptionsItemSelected(item);
    }

}