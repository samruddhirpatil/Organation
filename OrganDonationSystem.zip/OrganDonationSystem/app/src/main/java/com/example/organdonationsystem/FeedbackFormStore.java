package com.example.organdonationsystem;

public class FeedbackFormStore
{
    String mob,feedback;
public FeedbackFormStore(String mob,String feedback) {
        this.mob = mob;
        this.feedback = feedback;

        }
public FeedbackFormStore(){}
public String getMob() {
        return mob;
        }

public void setMob(String email) {
        this.mob = email;
        }

public String getFeedback() {
        return feedback;
        }

public void setFeedback(String feedback) {
        this.feedback = feedback;
        }
        }
