package com.example.organdonationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class ContactUs extends AppCompatActivity {
TextView name,email,mob;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        name=(TextView) findViewById(R.id.Name);
        mob=(TextView) findViewById(R.id.contactno);
        email=(TextView) findViewById(R.id.email);
        name.setText("Name:- Organation Team");
        email.setText("Email Id:- odonation2023@gmail.com");
        mob.setText("Contact No:- 9028325883\n  9511256762\n  9529638579");

    }
    public boolean onCreateOptionsMenu(Menu menu)
{
    MenuInflater m=getMenuInflater();
    m.inflate(R.menu.commonsidemenu, menu);
    return true;
}

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:

                Intent intent = new Intent(getApplicationContext(), IndexPage.class);
                startActivity(intent);
                break;
            case R.id.Doctor_Login:

                Intent intent2 = new Intent(getApplicationContext(), DoctorLogin.class);
                startActivity(intent2);
                break;
            case R.id.HospitalLogin:

                Intent intent4 = new Intent(getApplicationContext(),HospitalLogin.class);
                startActivity(intent4);
                break;
            case R.id.Donor:

                Intent intent3 = new Intent(getApplicationContext(),DonarLogin.class);
                startActivity(intent3);
                break;
            case R.id.Feedback:
                Intent intent6 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent6);
                break;
            case R.id.ContactUs:

                Intent intent5 = new Intent(getApplicationContext(), ContactUs.class);
                startActivity(intent5);
                break;
            case R.id.Receiver:

                Intent intent7 = new Intent(getApplicationContext(), OrganRecieveLogin.class);
                startActivity(intent7);
                break;


        }
        return super.onOptionsItemSelected(item);
    }
}