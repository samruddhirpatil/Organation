package com.example.organdonationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DoctorSignUp extends AppCompatActivity {

    EditText RegistrationNo,DoctName,Doctaddress,DoctContactNo,DoctEmailid,DoctUsername,DoctPass,DoctCPass;
    Button signupbtn;
    String RegistrationNo1,DoctName1,Doctaddress1,DoctContactNo1,DoctEmailid1,DoctUsername1,DoctPass1,DoctCPass1;
    DatabaseReference organDB;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_sign_up);
        RegistrationNo=(EditText) findViewById(R.id.RegistrationNo);
        DoctName=(EditText) findViewById(R.id.DoctName);
        Doctaddress=(EditText) findViewById(R.id.Doctaddress);
        DoctContactNo=(EditText) findViewById(R.id.DoctContactNo);
        DoctEmailid=(EditText) findViewById(R.id.DoctEmailid);
        DoctUsername=(EditText) findViewById(R.id.DoctUsername);
        DoctPass=(EditText) findViewById(R.id.DoctPass);
        DoctCPass=(EditText) findViewById(R.id.DoctCPass);
        signupbtn=(Button) findViewById(R.id.signupbtn);
        mAuth=FirebaseAuth.getInstance();
        organDB = FirebaseDatabase.getInstance().getReference().child("DoctorSignup");

        signupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegistrationNo1=RegistrationNo.getText().toString();
                DoctName1=DoctName.getText().toString();
                Doctaddress1=Doctaddress.getText().toString();
                DoctContactNo1=DoctContactNo.getText().toString().trim();
                DoctEmailid1=DoctEmailid.getText().toString().trim();
                DoctUsername1=DoctUsername.getText().toString();
                DoctPass1=DoctPass.getText().toString().trim();
                DoctCPass1=DoctCPass.getText().toString().trim();
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                if (DoctEmailid1.matches(emailPattern) && DoctEmailid1.length() > 0 && android.util.Patterns.PHONE.matcher(DoctContactNo1).matches()&& DoctPass1.length()>8 && isValidPassword(DoctPass1))
                {
                    //Toast.makeText(getApplicationContext(),"valid email address",Toast.LENGTH_SHORT).show();


                if(DoctPass1.equals(DoctCPass1))
                {
                    DoctorSignupInfoClass f = new DoctorSignupInfoClass(RegistrationNo1,DoctName1,Doctaddress1,DoctContactNo1,DoctEmailid1,DoctUsername1,DoctPass1);
                    // societydb.push().setValue(f);
                    organDB.child(DoctUsername1).setValue(f);
                    Toast.makeText(DoctorSignUp.this, "Signup successfully", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(DoctorSignUp.this, DonarLogin.class);
                    startActivity(i);
                }


            }
                else
                {
                    Toast.makeText(getApplicationContext(),"Invalid email address or email or password",Toast.LENGTH_SHORT).show();
                }
        }

        });
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
            MenuInflater m=getMenuInflater();
        m.inflate(R.menu.commonsidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
                Intent intent = new Intent(getApplicationContext(), IndexPage.class);
                startActivity(intent);
                break;
            case R.id.Doctor_Login:
                Intent intent2 = new Intent(getApplicationContext(), DoctorLogin.class);
                startActivity(intent2);
                break;
            case R.id.HospitalLogin:
                Intent intent3 = new Intent(getApplicationContext(),HospitalLogin.class);
                startActivity(intent3);
                break;
            case R.id.Donor:
                Intent intent4 = new Intent(getApplicationContext(),DonarLogin.class);
                startActivity(intent4);
                break;
            case R.id.Receiver:
                Intent intent5 = new Intent(getApplicationContext(), OrganRecieveLogin.class);
                startActivity(intent5);
                break;
            case R.id.Feedback:
                Intent intent6 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent6);
                break;
            case R.id.ContactUs:
                Intent intent7 = new Intent(getApplicationContext(), ContactUs.class);
                startActivity(intent7);
                break;

        }
        return super.onOptionsItemSelected(item);
    }
    public static boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();

    }
}