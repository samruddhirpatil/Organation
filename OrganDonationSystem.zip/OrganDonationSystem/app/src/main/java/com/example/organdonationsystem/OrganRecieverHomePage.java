package com.example.organdonationsystem;

//import static com.example.organdonationsystem.DonarLogin.activityname;

import static com.example.organdonationsystem.OrganRecieveLogin.activityname15;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class OrganRecieverHomePage extends AppCompatActivity {
    SharedPreferences sharedpreferences2;
    public static final String SHARED_PREFS2 = "shared_prefs2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_organ_reciever_home_page);
        sharedpreferences2 = getSharedPreferences(SHARED_PREFS2, Context.MODE_PRIVATE);
        // getting data from shared prefs and
        // storing it in our string variable.
        String  fn= sharedpreferences2.getString(activityname15, null);
        System.out.println("fn==="+fn);
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater m=getMenuInflater();
        m.inflate(R.menu.organrecieversidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
                Intent intent = new Intent(getApplicationContext(), OrganRecieverHomePage.class);
                startActivity(intent);
                break;
            case R.id.CheckOrganDonationInformation:
                Intent intent3 = new Intent(getApplicationContext(),CheckOrganDonationInformationToDonar.class);
                startActivity(intent3);
                break;
            case R.id.Feedback:
                Intent intent199 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent199);
                break;
            case R.id.changepass:
                Intent intent1990 = new Intent(getApplicationContext(), changePasswordForOrganReciever.class);
                startActivity(intent1990);
                break;
            case R.id.SignOut:
                Intent intent4 = new Intent(getApplicationContext(),IndexPage.class);
                startActivity(intent4);
                break;


        }
        return super.onOptionsItemSelected(item);
    }

}