package com.example.organdonationsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FeedbackForm extends AppCompatActivity {
    EditText feedback,email;
    Button store;
    DatabaseReference organdb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback_form);
        email=(EditText) findViewById(R.id.email);
        feedback=(EditText) findViewById(R.id.Feedback);
        store=(Button) findViewById(R.id.submit);
        organdb = FirebaseDatabase.getInstance().getReference().child("Feedback");
        store.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                storeFeedback();
            }
        });
    }
    public void storeFeedback()
    {
        String em=email.getText().toString();
        String feed=feedback.getText().toString();
        FeedbackFormStore f=new FeedbackFormStore(em,feed);
        // societydb.push().setValue(f);
        organdb.child(em).setValue(f);
        Toast.makeText(FeedbackForm.this,"Feedback Submitted",Toast.LENGTH_SHORT).show();
        Intent i = new Intent(FeedbackForm.this, IndexPage.class);
        startActivity(i);
    }
public boolean onCreateOptionsMenu(Menu menu)
{
    MenuInflater m=getMenuInflater();
    m.inflate(R.menu.feedbacksidemenu, menu);
    return true;
}
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
finish();
                break;

            case R.id.SignOut:

                Intent intent7 = new Intent(getApplicationContext(), IndexPage.class);
                startActivity(intent7);
                break;

        }
        return super.onOptionsItemSelected(item);
    }
}