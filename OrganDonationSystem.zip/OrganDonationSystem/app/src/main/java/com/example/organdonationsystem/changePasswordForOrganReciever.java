    package com.example.organdonationsystem;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

    public class changePasswordForOrganReciever extends AppCompatActivity {
        EditText username,pass,changepass,cpass;
        String username1,pass1,changepass1,cpass1;
        Button ChangePAss;
        TextView t1;
        DatabaseReference organDB;
        FirebaseAuth mAuth;
        SharedPreferences sharedpreferences15;
        public static final String USERNAME = "USERNAME";
        public static final String SHARED_PREFS15 = "shared_prefs15";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password_for_organ_reciever);
        ChangePAss=(Button) findViewById(R.id.send);
        username=(EditText) findViewById(R.id.username);
        // pass=(EditText) findViewById(R.id.pass);
        t1=(TextView)findViewById(R.id.age1);
        changepass=(EditText) findViewById(R.id.newpass);
        cpass=(EditText) findViewById(R.id.cpass);

        sharedpreferences15 = getSharedPreferences(SHARED_PREFS15, Context.MODE_PRIVATE);
        String  fn12= sharedpreferences15.getString(USERNAME, null);
        t1.setText("Change password for="+fn12);
        mAuth= FirebaseAuth.getInstance();
        organDB = FirebaseDatabase.getInstance().getReference().child("RecieverSignupDetails");

        ChangePAss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username1=username.getText().toString();
                // pass1=pass.getText().toString();
                changepass1=changepass.getText().toString();
                cpass1=cpass.getText().toString();
                if(changepass1.equals(cpass1))
                {
                    organDB.child(username1).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @SuppressLint("LongLogTag")
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {

                            if (!task.isSuccessful()) {
                                Log.e("firebase", "Error getting data", task.getException());
                            }
                            else {
                                organDB.child(username1).child("reciverPass1").setValue(changepass1);
                                organDB.child(username1).child("reciverCPass1").setValue(changepass1);
                                Toast.makeText(changePasswordForOrganReciever.this, "password change successfully", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(changePasswordForOrganReciever.this, OrganRecieverHomePage.class);
                                startActivity(i);
                            }}});}
                else {

                }
            }
        });




    }
    }