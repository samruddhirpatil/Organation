package com.example.organdonationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CheckAdmitPatient extends AppCompatActivity {
    private ListView listView;
    FirebaseDatabase database;
    // creating a new array list.
    ArrayList<String> list;
    ArrayAdapter<String> adapter;
    AddPateintClass feed;
    // creating a variable for database reference.
    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_admit_patient);
        feed=new AddPateintClass();
        listView = (ListView) findViewById(R.id.listView);
        database=FirebaseDatabase.getInstance();
        list=new ArrayList<>();
        ref = FirebaseDatabase.getInstance().getReference().child("AdmitPatientInfo");
        adapter=new ArrayAdapter<String>(this,R.layout.checkadmitpatientlayoutfile,R.id.Feedback_info,list);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int i=1;
                for(DataSnapshot ds:snapshot.getChildren())
                {
                    feed=ds.getValue(AddPateintClass.class);
                    list.add("\n"+i+" Registration no="+feed.getRegistrationNo1().toString()+"\nPatient Name= "+feed.getPatientName1().toString()+"\nContact No= "+feed.getPateintContactNo1().toString()+"\nAdmit date= "+feed.getDateInfo().toString()+"\nStatus= "+feed.getAdmitstatus().toString());
                    i++;
                }
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    } public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater m=getMenuInflater();
        m.inflate(R.menu.hospitalsidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
                Intent intent = new Intent(getApplicationContext(), HospitalHomePage.class);
                startActivity(intent);
                break;
            case R.id.FillOrganInformation:
                Intent intent2 = new Intent(getApplicationContext(), DonateOrgan.class);
                startActivity(intent2);
                break;
            case R.id.CheckOrganDonationInformation:
                Intent intent3 = new Intent(getApplicationContext(),CheckOrganDonationInformationToDonar.class);
                startActivity(intent3);
                break;
            case R.id.CheckFeedback:
                Intent intent31 = new Intent(getApplicationContext(),CheckFeedback.class);
                startActivity(intent31);
                break;
            case R.id.changepass:
                Intent intent311= new Intent(getApplicationContext(),ChangePasswordForHospital.class);
                startActivity(intent311);
                break;
            case R.id.Feedback:
                Intent intent199 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent199);
                break;
            case R.id.SignOut:
                Intent intent4 = new Intent(getApplicationContext(),IndexPage.class);
                startActivity(intent4);
                break;
            case R.id.AdmitPatient:
                Intent intent41 = new Intent(getApplicationContext(),AddPatient.class);
                startActivity(intent41);
                break;
            case R.id.CheckAdmitPatient:
                Intent intent421 = new Intent(getApplicationContext(),CheckAdmitPatient.class);
                startActivity(intent421);
                break;
            case R.id.ReleasePatient:
                Intent intent4211 = new Intent(getApplicationContext(),DischargePatientByHospital.class);
                startActivity(intent4211);
                break;

        }
        return super.onOptionsItemSelected(item);
    }

}