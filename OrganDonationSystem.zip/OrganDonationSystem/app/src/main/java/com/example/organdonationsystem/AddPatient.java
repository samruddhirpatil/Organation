package com.example.organdonationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddPatient extends AppCompatActivity {
    EditText RegistrationNo,PatientName,PateintContactNo,Emailid;
    Button Store;
    DatePicker date1;
    String Admitstatus="admit";
    String dateInfo,RegistrationNo1,PatientName1,PateintContactNo1,Emailid1;
    DatabaseReference organDB;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_patient);
        RegistrationNo=(EditText) findViewById(R.id.RegistrationNo);
        PatientName=(EditText) findViewById(R.id.PatientName);
        PateintContactNo=(EditText) findViewById(R.id.PateintContactNo);
        Emailid=(EditText) findViewById(R.id.Emailid);
        Store=(Button) findViewById(R.id.Store);
        mAuth= FirebaseAuth.getInstance();
        date1=(DatePicker)findViewById(R.id.date1);
        organDB = FirebaseDatabase.getInstance().getReference().child("AdmitPatientInfo");

        Store.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegistrationNo1=RegistrationNo.getText().toString();
                PatientName1=PatientName.getText().toString();
                PateintContactNo1=PateintContactNo.getText().toString();
                Emailid1=Emailid.getText().toString();
                dateInfo=(date1.getDayOfMonth()+"/"+ (date1.getMonth() + 1)+"/"+date1.getYear());
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                if (Emailid1.matches(emailPattern) && Emailid1.length() > 0 && android.util.Patterns.PHONE.matcher(PateintContactNo1).matches())
                {
                         AddPateintClass f = new AddPateintClass(RegistrationNo1,PatientName1,PateintContactNo1,Emailid1,dateInfo,Admitstatus);
                        organDB.child(RegistrationNo1).setValue(f);
                        Toast.makeText(AddPatient.this, "Store Info successfully", Toast.LENGTH_SHORT).show();




                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Invalid email address or email or password",Toast.LENGTH_SHORT).show();
                }
            }


        });
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater m=getMenuInflater();
        m.inflate(R.menu.hospitalsidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
                Intent intent = new Intent(getApplicationContext(), HospitalHomePage.class);
                startActivity(intent);
                break;
            case R.id.FillOrganInformation:
                Intent intent2 = new Intent(getApplicationContext(), DonateOrgan.class);
                startActivity(intent2);
                break;
            case R.id.CheckOrganDonationInformation:
                Intent intent3 = new Intent(getApplicationContext(),CheckOrganDonationInformationToDonar.class);
                startActivity(intent3);
                break;
            case R.id.CheckFeedback:
                Intent intent31 = new Intent(getApplicationContext(),CheckFeedback.class);
                startActivity(intent31);
                break;
            case R.id.changepass:
                Intent intent311= new Intent(getApplicationContext(),ChangePasswordForHospital.class);
                startActivity(intent311);
                break;
            case R.id.Feedback:
                Intent intent199 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent199);
                break;
            case R.id.SignOut:
                Intent intent4 = new Intent(getApplicationContext(),IndexPage.class);
                startActivity(intent4);
                break;
            case R.id.AdmitPatient:
                Intent intent41 = new Intent(getApplicationContext(),AddPatient.class);
                startActivity(intent41);
                break;
            case R.id.CheckAdmitPatient:
                Intent intent421 = new Intent(getApplicationContext(),CheckAdmitPatient.class);
                startActivity(intent421);
                break;
            case R.id.ReleasePatient:
                Intent intent4211 = new Intent(getApplicationContext(),DischargePatientByHospital.class);
                startActivity(intent4211);
                break;

        }
        return super.onOptionsItemSelected(item);
    }

}