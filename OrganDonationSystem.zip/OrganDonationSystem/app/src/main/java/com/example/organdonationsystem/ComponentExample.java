package com.example.organdonationsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ComponentExample extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_component_example);
    }
}