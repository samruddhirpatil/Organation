package com.example.organdonationsystem;

//import static com.example.organdonationsystem.DonarLogin.activityname1;

import static com.example.organdonationsystem.HospitalLogin.activityname14;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class HospitalHomePage extends AppCompatActivity {
    SharedPreferences sharedpreferences14;
    public static final String SHARED_PREFS14 = "shared_prefs14";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital_home_page);
        sharedpreferences14 = getSharedPreferences(SHARED_PREFS14, Context.MODE_PRIVATE);
        // getting data from shared prefs and
        // storing it in our string variable.
        String  fn= sharedpreferences14.getString(activityname14, null);
        System.out.println("fn="+fn);
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater m=getMenuInflater();
        m.inflate(R.menu.hospitalsidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
                Intent intent = new Intent(getApplicationContext(), HospitalHomePage.class);
                startActivity(intent);
                break;
            case R.id.FillOrganInformation:
                Intent intent2 = new Intent(getApplicationContext(), DonateOrgan.class);
                startActivity(intent2);
                break;
            case R.id.CheckOrganDonationInformation:
                Intent intent3 = new Intent(getApplicationContext(),CheckOrganDonationInformationToDonar.class);
                startActivity(intent3);
                break;
            case R.id.CheckFeedback:
                Intent intent31 = new Intent(getApplicationContext(),CheckFeedback.class);
                startActivity(intent31);
                break;
            case R.id.changepass:
                Intent intent311= new Intent(getApplicationContext(),ChangePasswordForHospital.class);
                startActivity(intent311);
                break;
            case R.id.Feedback:
                Intent intent199 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent199);
                break;
            case R.id.SignOut:
                Intent intent4 = new Intent(getApplicationContext(),IndexPage.class);
                startActivity(intent4);
                break;
            case R.id.AdmitPatient:
                Intent intent41 = new Intent(getApplicationContext(),AddPatient.class);
                startActivity(intent41);
                break;
            case R.id.CheckAdmitPatient:
                Intent intent421 = new Intent(getApplicationContext(),CheckAdmitPatient.class);
                startActivity(intent421);
                break;
            case R.id.ReleasePatient:
                Intent intent4211 = new Intent(getApplicationContext(),DischargePatientByHospital.class);
                startActivity(intent4211);
                break;

        }
        return super.onOptionsItemSelected(item);
    }

}