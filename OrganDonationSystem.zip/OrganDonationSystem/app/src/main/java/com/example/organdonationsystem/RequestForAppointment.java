package com.example.organdonationsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.DatePicker;

public class RequestForAppointment extends AppCompatActivity {
    DatePicker simpleDatePicker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_for_appointment);
        simpleDatePicker = (DatePicker)findViewById(R.id.simpleDatePicker); // initiate a date picker
        simpleDatePicker.setSpinnersShown(false);
        int day = simpleDatePicker.getDayOfMonth(); // get the selected day of the month
        int month = simpleDatePicker.getMonth(); // get the selected month
        int year = simpleDatePicker.getYear(); // get the selected year
    }
}