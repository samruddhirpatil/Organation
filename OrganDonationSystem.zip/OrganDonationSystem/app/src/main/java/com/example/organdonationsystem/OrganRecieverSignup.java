package com.example.organdonationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OrganRecieverSignup extends AppCompatActivity {
Button signup;
    DatabaseReference organDB;
    FirebaseAuth mAuth;
EditText ReceiverName,ReceiverAddress,ReceiverContactNo,ReceiverEmailid,RecieverUsername,ReciverPass,ReciverCPass;
String ReceiverName1,ReceiverAddress1,HospContactNo1,HospEmailid1,RecieverUsername1,ReciverPass1,ReciverCPass1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_organ_reciever_signup);
        signup=(Button) findViewById(R.id.signupbtn);
        ReceiverName=(EditText)findViewById(R.id.ReceiverName);
        ReceiverAddress=(EditText) findViewById(R.id.ReceiverAddress);
        ReceiverContactNo=(EditText) findViewById(R.id.HospContactNo);
        ReceiverEmailid=(EditText)findViewById(R.id.HospEmailid);
        RecieverUsername=(EditText)findViewById(R.id.HospUsername);
        ReciverPass=(EditText)findViewById(R.id.HospPass);
        ReciverCPass=(EditText)findViewById(R.id.HospCPass);
        mAuth= FirebaseAuth.getInstance();
        organDB = FirebaseDatabase.getInstance().getReference().child("RecieverSignupDetails");

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ReceiverName1=ReceiverName.getText().toString();
                ReceiverAddress1=ReceiverAddress.getText().toString();
                HospContactNo1=ReceiverContactNo.getText().toString();
                HospEmailid1=ReceiverEmailid.getText().toString().trim();
                RecieverUsername1=RecieverUsername.getText().toString();
                ReciverPass1=ReciverPass.getText().toString().trim();
                ReciverCPass1=ReciverCPass.getText().toString().trim();
                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                if (HospEmailid1.matches(emailPattern) && HospEmailid1.length() > 0 && android.util.Patterns.PHONE.matcher(HospContactNo1).matches()&& ReciverPass1.length()>8 && isValidPassword(ReciverPass1))
                {
                    //Toast.makeText(getApplicationContext(),"valid email address",Toast.LENGTH_SHORT).show();


                    if(ReciverPass1.equals(ReciverCPass1))
                {
                    RecieverSignupDetailsStoreClass f = new RecieverSignupDetailsStoreClass(ReceiverName1,ReceiverAddress1,HospContactNo1,HospEmailid1,RecieverUsername1,ReciverPass1,ReciverCPass1);
                    // societydb.push().setValue(f);
                    organDB.child(RecieverUsername1).setValue(f);
                    Toast.makeText(OrganRecieverSignup.this, "Signup successfully", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(OrganRecieverSignup.this, OrganRecieveLogin.class);
                    startActivity(i);
                }}else{
                    Toast.makeText(getApplicationContext(),"Invalid email address or email or password",Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater m=getMenuInflater();
        m.inflate(R.menu.commonsidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
                Intent intent = new Intent(getApplicationContext(), IndexPage.class);
                startActivity(intent);
                break;
            case R.id.Doctor_Login:
                Intent intent2 = new Intent(getApplicationContext(), DoctorLogin.class);
                startActivity(intent2);
                break;
            case R.id.HospitalLogin:
                Intent intent3 = new Intent(getApplicationContext(),HospitalLogin.class);
                startActivity(intent3);
                break;
            case R.id.Donor:
                Intent intent4 = new Intent(getApplicationContext(),DonarLogin.class);
                startActivity(intent4);
                break;
            case R.id.Receiver:
                Intent intent5 = new Intent(getApplicationContext(), OrganRecieveLogin.class);
                startActivity(intent5);
                break;
            case R.id.Feedback:
                Intent intent6 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent6);
                break;
            case R.id.ContactUs:
                Intent intent7 = new Intent(getApplicationContext(), ContactUs.class);
                startActivity(intent7);
                break;

        }
        return super.onOptionsItemSelected(item);
    }
        public static boolean isValidPassword(final String password) {

            Pattern pattern;
            Matcher matcher;
            final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
            pattern = Pattern.compile(PASSWORD_PATTERN);
            matcher = pattern.matcher(password);

            return matcher.matches();

        }
}