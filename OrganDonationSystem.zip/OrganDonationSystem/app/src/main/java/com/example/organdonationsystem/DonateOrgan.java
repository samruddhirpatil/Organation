package com.example.organdonationsystem;

import static com.example.organdonationsystem.DoctorLogin.activityname13;
import static com.example.organdonationsystem.DonarLogin.activityname12;
import static com.example.organdonationsystem.HospitalLogin.activityname14;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class DonateOrgan extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    EditText DonarName,age,DonarAddress,DonarContactNo,DonarEmailid,Adhar,OrganName,WhenDonate;
    RadioButton radioMale,radioFemale;
    String[] courses = { "kidneys","liver","lungs","heart","pancreas","intestine","hands","face","blood","eyes"};
    String[] WhenDonate1={"After Death","Before Death"};
    String  DonarName1,age1,DonarAddress1,DonarContactNo1,DonarEmailid1,Adhar1,OrganName1;
    String gender="null";
    Button signupbtn;
    DatabaseReference organDB;
    FirebaseAuth mAuth;
    String fn,fn1,fn2,fn4="0",fn12="0",fn13="0",fn14="0",fn15="0";
    SharedPreferences sharedpreferences,sharedpreferences12,sharedpreferences13,sharedpreferences14,sharedpreferences15;
    public static final String SHARED_PREFS = "shared_prefs";
    public static final String SHARED_PREFS12 = "shared_prefs12";
    public static final String SHARED_PREFS13 = "shared_prefs13";
    public static final String SHARED_PREFS14 = "shared_prefs14";
    public static final String SHARED_PREFS15 = "shared_prefs15";
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donate_organ);
        Spinner spino = findViewById(R.id.coursesspinner);
        spino.setOnItemSelectedListener(this);
        Spinner spino1 = findViewById(R.id.WhenDonate1);
        spino1.setOnItemSelectedListener(this);
        DonarName=(EditText) findViewById(R.id.DonarName);
        age=(EditText) findViewById(R.id.age);
        DonarAddress=(EditText) findViewById(R.id.DonarAddress);
        DonarContactNo=(EditText) findViewById(R.id.DonarContactNo);
        DonarEmailid=(EditText) findViewById(R.id.DonarEmailid);
        Adhar=(EditText) findViewById(R.id.Adhar);
        //OrganName=(EditText) findViewById(R.id.OrganName);
       // WhenDonate=(EditText) findViewById(R.id.WhenDonate);
        signupbtn=(Button) findViewById(R.id.signupbtn);
        sharedpreferences = getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
        sharedpreferences12 = getSharedPreferences(SHARED_PREFS12, Context.MODE_PRIVATE);
        sharedpreferences13 = getSharedPreferences(SHARED_PREFS13, Context.MODE_PRIVATE);
        sharedpreferences14 = getSharedPreferences(SHARED_PREFS14, Context.MODE_PRIVATE);
        sharedpreferences15 = getSharedPreferences(SHARED_PREFS15, Context.MODE_PRIVATE);
        fn12= sharedpreferences12.getString(activityname12, null);
        System.out.println("Fn12="+fn12);
        fn13= sharedpreferences13.getString(activityname13, null);
        System.out.println("Fn13="+fn13);
        fn14= sharedpreferences14.getString(activityname14, null);
        System.out.println("Fn14="+fn14);
        fn15= sharedpreferences15.getString(activityname13,null);
        System.out.println("Fn=15"+fn15);
        radioMale=(RadioButton) findViewById(R.id.radioMale);
        radioFemale=(RadioButton) findViewById(R.id.radioFemale);
        String s1=getClass().getName();
        mAuth= FirebaseAuth.getInstance();
        organDB = FirebaseDatabase.getInstance().getReference().child("DonateOraganInfo");
        System.out.println("Database name="+organDB);
        ArrayAdapter ad
                = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                courses);

        // set simple layout resource file
        // for each item of spinner
        ad.setDropDownViewResource(
                android.R.layout
                        .simple_spinner_dropdown_item);

        // Set the ArrayAdapter (ad) data on the
        // Spinner which binds data to spinner
        spino.setAdapter(ad);
//-----------------------------------------------------------------
        ArrayAdapter ad1
                = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                WhenDonate1);
        ad.setDropDownViewResource(
                android.R.layout
                        .simple_spinner_dropdown_item);
        spino1.setAdapter(ad1);
        try {

        signupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DonarName1 =DonarName.getText().toString();
                age1=age.getText().toString();
                DonarAddress1 =DonarAddress.getText().toString();
                DonarContactNo1=DonarContactNo.getText().toString();
                DonarEmailid1=DonarEmailid.getText().toString();
                Adhar1=Adhar.getText().toString();
               // OrganName1=OrganName.getText().toString();
               // WhenDonate1=WhenDonate.getText().toString();
                String organname = spino.getSelectedItem().toString();
                String WHENDonate = spino1.getSelectedItem().toString();
                if(radioFemale.isChecked())
                {
                    gender="female";
                }
                else if(radioMale.isChecked())
                {
                    gender="male";
                }
                String donatedStatus="Yet not donated";
                String alive="alive";
             //   String[] courses = { "kidneys","liver","lungs","heart","pancreas","intestine","hands","face","blood","eyes"};

                if((WHENDonate.equals("After Death")&& (organname.equals("kidneys") ||organname.equals("liver")||organname.equals("lungs")||organname.equals("heart")||organname.equals("pancreas")||organname.equals("intestine")||organname.equals("hands")||organname.equals("eyes")))||(WHENDonate.equals("Before Death")&& (organname.equals("kidneys") ||organname.equals("liver")||organname.equals("lungs")||organname.equals("pancreas")||organname.equals("intestine")||organname.equals("eyes")||organname.equals("blood")||organname.equals("face"))))
                {
                    DonateOrganDetailsStoreClass f = new DonateOrganDetailsStoreClass(DonarName1, age1, DonarAddress1, DonarContactNo1, DonarEmailid1, Adhar1, organname, WHENDonate, gender, donatedStatus, alive);
                    organDB.child(organname).setValue(f);
                    Toast.makeText(DonateOrgan.this, "Store info successfully", Toast.LENGTH_SHORT).show();
                    System.out.println("Activity name="+fn);
                }
                else
                {
                    Toast.makeText(DonateOrgan.this, "Donate organ and when to donate not matched", Toast.LENGTH_SHORT).show();

                }
              /*  if(fn.equals("Donor"))
                {
                    Intent i = new Intent(DonateOrgan.this, DonorHomePage.class);
                    startActivity(i);
                }
                else if(fn4.equals("doctor"))
                {
                    Intent i1 = new Intent(DonateOrgan.this, DoctorHomePage.class);
                    startActivity(i1);
                }
                if(fn1.equals("Hospital"))
                {
                    Intent i2 = new Intent(DonateOrgan.this, HospitalHomePage.class);
                    startActivity(i2);
                }
                else if(fn2.equals("OrganReciver"))
                {
                    Intent i = new Intent(DonateOrgan.this, DoctorHomePage.class);
                    startActivity(i);
                }
*/
            }
        });}catch (Exception e){System.out.println("error"+e);}
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(getApplicationContext(),
                        courses[position],
                        Toast.LENGTH_LONG)
                .show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater m=getMenuInflater();
        m.inflate(R.menu.donorsidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
             /*   if(fn12.equals("Donor"))
                {
                    Intent i = new Intent(DonateOrgan.this, DonorHomePage.class);
                    startActivity(i);
                }
                  if(fn13.equals("doctor"))
                {
                    Intent i1 = new Intent(DonateOrgan.this, DoctorHomePage.class);
                    startActivity(i1);
                }
                 if(fn14.equals("Hospital"))
                {
                    Intent i2 = new Intent(DonateOrgan.this, HospitalHomePage.class);
                    startActivity(i2);
                }
                 if(fn15.equals("OrganReciver"))
                {
                    Intent i = new Intent(DonateOrgan.this, DoctorHomePage.class);
                    startActivity(i);
                }*/
                finish();
                break;
            case R.id.FillOrganInformation:
                Intent intent2 = new Intent(getApplicationContext(), DonateOrgan.class);
                startActivity(intent2);
                break;
            case R.id.Feedback:
                Intent intent199 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent199);
                break;
            case R.id.SignOut:
                Intent intent4 = new Intent(getApplicationContext(),IndexPage.class);
                startActivity(intent4);
                break;


        }
        return super.onOptionsItemSelected(item);
    }

}