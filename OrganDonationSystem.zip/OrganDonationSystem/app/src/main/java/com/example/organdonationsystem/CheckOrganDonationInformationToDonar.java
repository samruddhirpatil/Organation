package com.example.organdonationsystem;

//import static com.example.organdonationsystem.DoctorLogin.activityname;
import static com.example.organdonationsystem.DoctorLogin.activityname13;
import static com.example.organdonationsystem.DonarLogin.activityname12;
import static com.example.organdonationsystem.HospitalLogin.activityname14;
import static com.example.organdonationsystem.OrganRecieveLogin.activityname15;
//import static com.example.organdonationsystem.HospitalLogin.activityname1;
//import static com.example.organdonationsystem.OrganRecieveLogin.activityname2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.view.View;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.os.Bundle;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CheckOrganDonationInformationToDonar extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    String[] courses = { "kidneys","liver","lungs","heart","pancreas","intestine","hands","face","blood","eyes"};
    Button check;
    SharedPreferences sharedpreferences12;
    SharedPreferences sharedpreferences13;
    SharedPreferences sharedpreferences14;
    SharedPreferences sharedpreferences15;
    DonateOrganDetailsStoreClass feed;
    private ListView listView;
    public static final String SHARED_PREFS12 = "shared_prefs12";
    public static final String SHARED_PREFS13 = "shared_prefs13";
    public static final String SHARED_PREFS14 = "shared_prefs14";
    public static final String SHARED_PREFS15 = "shared_prefs15";

    FirebaseDatabase database;
    // creating a new array list.
    ArrayList<String> list;
    ArrayAdapter<String> adapter;
    String fn12="0",fn13="0",fn14="0",fn15="0";
    // creating a variable for database reference.
    DatabaseReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_organ_donation_information_to_donar);
        Spinner spino = findViewById(R.id.coursesspinner);
        spino.setOnItemSelectedListener(this);
        feed=new DonateOrganDetailsStoreClass();
        check = (Button) findViewById(R.id.check);
        listView = (ListView) findViewById(R.id.listView);
        database = FirebaseDatabase.getInstance();
        list = new ArrayList<>();
        sharedpreferences12 = getSharedPreferences(SHARED_PREFS12, Context.MODE_PRIVATE);
        sharedpreferences13 = getSharedPreferences(SHARED_PREFS13, Context.MODE_PRIVATE);
        sharedpreferences14 = getSharedPreferences(SHARED_PREFS14, Context.MODE_PRIVATE);
        sharedpreferences15 = getSharedPreferences(SHARED_PREFS15, Context.MODE_PRIVATE);


        fn12= sharedpreferences12.getString(activityname12, null);
        fn13= sharedpreferences13.getString(activityname13, null);
        fn14= sharedpreferences14.getString(activityname14, null);
        fn15=sharedpreferences15.getString(activityname15,null);
        System.out.println("fn12="+fn12);
        System.out.println("fn13="+fn13);
        System.out.println("fn14="+fn14);
        System.out.println("fn15="+fn15);
        if(fn12==null)
        {
            fn12="0";
        }
        if(fn13==null)
        {
            fn13="0";
        }
        if(fn14==null)
        {
            fn14="0";
        }
        if(fn15==null)
        {
            fn15="0";
        } System.out.println("**fn12="+fn12);
        System.out.println("**fn13="+fn13);
        System.out.println("**fn14="+fn14);
        System.out.println("**fn15="+fn15);
        ref = FirebaseDatabase.getInstance().getReference().child("DonateOraganInfo");
        adapter = new ArrayAdapter<String>(this, R.layout.donatedrgandetailsxmlfile, R.id.Feedback_info, list);

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String organname = spino.getSelectedItem().toString();
                System.out.println("selected organ="+organname);
                System.out.println("Hi1");
               Loop: ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        System.out.println("Hi2");
                        int i = 1;
                        for (DataSnapshot ds : snapshot.getChildren()) {
                            System.out.println("Hi3");
                            feed = ds.getValue(DonateOrganDetailsStoreClass.class);
                            System.out.println("selected organ="+organname);
                            System.out.println("Feed.getOrgan="+feed.getOrganName1());
                            if(organname.equals(feed.getOrganName1()))
                            {
                            list.add("\n" + i + " Donor name=" + feed.getDonarName1().toString() + "\nContact no= " + feed.getDonarContactNo1().toString() + "\nAddress= " + feed.getDonarAddress1().toString() +  "\nage= " + feed.getAge1().toString()  + "\nEmail id= " + feed.getDonarEmailid1().toString()  + "\nGender= " + feed.getGender().toString()  + "\nWhen Donate= " + feed.getWhenDonate1().toString()  + "\nalive or dead= " + feed.getAlive().toString()  + "\nDonated or not= " + feed.getDonatedStatus().toString()+"\n----------------------------------------------"     );
                            i++;
                            }
                        listView.setAdapter(adapter);}
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });
        ArrayAdapter ad
                = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                courses);

        // set simple layout resource file
        // for each item of spinner
        ad.setDropDownViewResource(
                android.R.layout
                        .simple_spinner_dropdown_item);

        // Set the ArrayAdapter (ad) data on the
        // Spinner which binds data to spinner
        spino.setAdapter(ad);
    }

    // Performing action when ItemSelected
    // from spinner, Overriding onItemSelected method

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(getApplicationContext(),
                        courses[position],
                        Toast.LENGTH_LONG)
                .show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
/*    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater m=getMenuInflater();
        m.inflate(R.menu.organrecieversidemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
               if(fn12.equals("Donor"))
                {
                    Intent i = new Intent(CheckOrganDonationInformationToDonar.this, DonorHomePage.class);
                    startActivity(i);
                }
                else if(fn13.equals("doctor"))
                {
                    Intent i1 = new Intent(CheckOrganDonationInformationToDonar.this, DoctorHomePage.class);
                    startActivity(i1);
                }
                else if(fn14.equals("Hospital"))
                {
                    Intent i2 = new Intent(CheckOrganDonationInformationToDonar.this, HospitalHomePage.class);
                    startActivity(i2);
                }
                else if(fn15.equals("OrganReciver"))
                {
                    Intent i3 = new Intent(CheckOrganDonationInformationToDonar.this, OrganRecieverHomePage.class);
                    startActivity(i3);
                }
                finish();
            break;
            case R.id.CheckOrganDonationInformation:
                Intent intent3 = new Intent(getApplicationContext(),CheckOrganDonationInformationToDonar.class);
                startActivity(intent3);
                break;
            case R.id.SignOut:
                Intent intent4 = new Intent(getApplicationContext(),IndexPage.class);
                startActivity(intent4);
                break;


        }
        return super.onOptionsItemSelected(item);
    }*/
}
