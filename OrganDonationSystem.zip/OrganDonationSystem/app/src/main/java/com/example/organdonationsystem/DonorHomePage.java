package com.example.organdonationsystem;

//import static com.example.organdonationsystem.DonarLogin.activityname;

import static com.example.organdonationsystem.DonarLogin.activityname12;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class DonorHomePage extends AppCompatActivity {
    SharedPreferences sharedpreferences12;
    public static final String SHARED_PREFS12 = "shared_prefs12";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor_home_page);
        sharedpreferences12 = getSharedPreferences(SHARED_PREFS12, Context.MODE_PRIVATE);
        // getting data from shared prefs and
        // storing it in our string variable.
        String  fn= sharedpreferences12.getString(activityname12, null);

    }
 public boolean onCreateOptionsMenu(Menu menu)
{
    MenuInflater m=getMenuInflater();
    m.inflate(R.menu.donorsidemenu, menu);
    return true;
}

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.Home_page:
                Intent intent = new Intent(getApplicationContext(), DonorHomePage.class);
                startActivity(intent);
                break;
            case R.id.FillOrganInformation:
                Intent intent2 = new Intent(getApplicationContext(), DonateOrgan.class);
                startActivity(intent2);
                break;
            case R.id.CheckOrganDonationInformation:
                Intent intent3 = new Intent(getApplicationContext(),CheckOrganDonationInformationToDonar.class);
                startActivity(intent3);
                break;
            case R.id.Feedback:
                Intent intent199 = new Intent(getApplicationContext(), FeedbackForm.class);
                startActivity(intent199);
                break;
            case R.id.changepass:
                Intent intent1990 = new Intent(getApplicationContext(), ChangePasswordForDonor.class);
                startActivity(intent1990);
                break;
            case R.id.SignOut:
                Intent intent4 = new Intent(getApplicationContext(),IndexPage.class);
                startActivity(intent4);
                break;


        }
        return super.onOptionsItemSelected(item);
    }
}