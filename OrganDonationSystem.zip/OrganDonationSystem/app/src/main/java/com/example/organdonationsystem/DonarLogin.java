package com.example.organdonationsystem;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.core.utilities.Validation;

public class DonarLogin extends AppCompatActivity {
Button signup,loginbtn1;
    SharedPreferences sharedpreferences12;
    DatabaseReference reference;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    DatabaseReference organdb;
    public static final String MyPREFERENCES = "MyPrefs";
    String user;
    Validation validation;
    public static final String SHARED_PREFS12 = "shared_prefs12";

    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    public static final String SharedUser = "usernameData";
    public static final String USERNAME = "USERNAME";
   // public static final String activityname12 = "donor";
    public static final String activityname12 = "null";

    public static final String PASSWORD_KEY = "email_key";
    EditText username1,password1;
    String u,p;
    TextView linkTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donar_login);
        signup = (Button) findViewById(R.id.signupbtn);
        username1 = (EditText) findViewById(R.id.username1);
        password1 = (EditText) findViewById(R.id.password1);
        linkTextView = findViewById(R.id.activity_main_link);
        linkTextView.setMovementMethod(LinkMovementMethod.getInstance());
        linkTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ForgetPasswordForDonor.class);
                startActivity(intent);
            }
        });
        organdb = FirebaseDatabase.getInstance().getReference().child("DonorSignupInfo");
        sharedpreferences12 = getSharedPreferences(SHARED_PREFS12, Context.MODE_PRIVATE);
        loginbtn1=(Button)findViewById(R.id.loginbtn1);
        loginbtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                u = username1.getText().toString();
                p = password1.getText().toString();
                organdb.child(u).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DataSnapshot> task) {
                        if (!task.isSuccessful()) {
                            Log.e("firebase", "Error getting data", task.getException());
                        } else {
                            String authpass = task.getResult().child("donorPass1").getValue().toString();
                            System.out.println("Auth=" + authpass);
                            SharedPreferences.Editor editor = sharedpreferences12.edit();
                            System.out.println("Username=" + u);
                            editor.putString(USERNAME, u);
                            editor.putString(PASSWORD_KEY, p);
                            editor.putString(activityname12,"Donor");
                            System.out.println("password=" + p);
                            System.out.println("PASSWORD_KEY=" + p);
                            // to save our data with key and value.
                            editor.apply();
                            if (p.equals(authpass)) {
                                Toast.makeText(DonarLogin.this, "Login sucessfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(DonarLogin.this, DonorHomePage.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(DonarLogin.this, "Username or password does not match", Toast.LENGTH_SHORT).show();

                            }
                            // Log.d("firebase", "data is"+String.valueOf(task.getResult().getValue()));
                        }
                    }
                });
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), DonorSignUp.class);
                startActivity(intent);
            }
        });
    }
                public boolean onCreateOptionsMenu (Menu menu)
                {
                    MenuInflater m = getMenuInflater();
                    m.inflate(R.menu.commonsidemenu, menu);
                    return true;
                }

                @Override
                public boolean onOptionsItemSelected (@NonNull MenuItem item){
                    switch (item.getItemId()) {
                        case R.id.Home_page:

                            Intent intent = new Intent(getApplicationContext(), IndexPage.class);
                            startActivity(intent);
                            break;
                        case R.id.Doctor_Login:

                            Intent intent2 = new Intent(getApplicationContext(), DoctorLogin.class);
                            startActivity(intent2);
                            break;
                        case R.id.HospitalLogin:

                            Intent intent4 = new Intent(getApplicationContext(), HospitalLogin.class);
                            startActivity(intent4);
                            break;
                        case R.id.Donor:

                            Intent intent3 = new Intent(getApplicationContext(), DonarLogin.class);
                            startActivity(intent3);
                            break;
                        case R.id.Feedback:
                            Intent intent6 = new Intent(getApplicationContext(), FeedbackForm.class);
                            startActivity(intent6);
                            break;
                        case R.id.ContactUs:

                            Intent intent5 = new Intent(getApplicationContext(), ContactUs.class);
                            startActivity(intent5);
                            break;
                        case R.id.Receiver:

                            Intent intent7 = new Intent(getApplicationContext(), OrganRecieveLogin.class);
                            startActivity(intent7);
                            break;
                    }
                    return super.onOptionsItemSelected(item);
                }
            }